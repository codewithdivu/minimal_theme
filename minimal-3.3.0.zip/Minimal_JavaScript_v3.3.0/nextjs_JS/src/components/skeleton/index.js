export { default as SkeletonMap } from './SkeletonMap';
export { default as SkeletonPost } from './SkeletonPost';
export { default as SkeletonProduct } from './SkeletonProduct';
export { default as SkeletonPostItem } from './SkeletonPostItem';
export { default as SkeletonProductItem } from './SkeletonProductItem';
export { default as SkeletonKanbanColumn } from './SkeletonKanbanColumn';
export { default as SkeletonMailSidebarItem } from './SkeletonMailSidebarItem';
export { default as SkeletonConversationItem } from './SkeletonConversationItem';
