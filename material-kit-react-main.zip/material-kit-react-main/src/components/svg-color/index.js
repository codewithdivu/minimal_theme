export { default } from './SvgColor';
